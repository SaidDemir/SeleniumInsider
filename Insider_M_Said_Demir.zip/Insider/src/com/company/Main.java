package com.company;

import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

/***
 * @author Said Demir
 * @version 13.02.2020
 * Java-selenium application.
 */
public class Main {

    public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
        WebDriver driver = new ChromeDriver();

        //Sayfaya giriş. Normal amazon 2 step verification yaptığı için türkiye sayfasından devam ettim.
        driver.get("http://www.amazon.com.tr");
        Thread.sleep(1000);

        //Sayfaya girişi onaylamak
        Assertions.assertEquals("Amazon.com.tr: Elektronik, bilgisayar, akıllı telefon, kitap, oyuncak, yapı market, ev, mutfak, oyun konsolları ürünleri ve daha fazlası için internet alışveriş sitesi", driver.getTitle(), "Title doesn't match, we're in the wrong place.");

        //Log-in'e giriş
        WebElement login = driver.findElement(By.xpath("//span[text() = 'Merhaba, Giriş yap']"));
        login.click();
        Thread.sleep(500);

        //Mail yollamak, kendi telefon numaram ve bu iş için oluşturduğum amazon hesabım. Lütfen bir şey satın almayın :)
        WebElement email = driver.findElement(By.name("email"));
        email.sendKeys("+905515541445");
        email.submit();
        Thread.sleep(500);

        //Şifre yollamak.
        WebElement password = driver.findElement(By.name("password"));
        password.sendKeys("Insider");
        password.submit();
        Thread.sleep(500);

        //Searchbox'u bulup samsung yazmak
        WebElement search = driver.findElement(By.id("twotabsearchtextbox"));
        search.sendKeys("samsung");
        Thread.sleep(500);

        //Normalde direkt search.submit yapardım ancak butona tıklasın istemişsiniz: buton kısmı
        WebElement searchButton = driver.findElement(By.className("nav-input"));
        searchButton.click();
        Thread.sleep(1000);


        //Samsung özel bir marka olduğundan bir samsung fotoğrafı çıkyıor, onu check ediyorum.
        Assertions.assertNotNull(driver.findElement(By.xpath("//img[@alt = 'Samsung']")), "Can't find the samsung logo, we're in the wrong place");


        //2. sayfaya tıklamak
        WebElement secondPage = driver.findElement(By.xpath("//li[@class = 'a-normal']//a[text() = '2']"));
        secondPage.click();
        Thread.sleep(1000);

        //2. sayfa şuan seçili mi diye bakmak
        Assertions.assertNotNull(driver.findElement(By.xpath("//li[@class = 'a-selected']//a[text() = '2']")), "2nd page is not selected, somethings wrong");

        //Sayfadaki 3. ürünün ismini çekmek
        String itemName = driver.findElement(By.xpath("//div[@data-index = '2']//span[@class = 'a-size-base-plus a-color-base a-text-normal']")).getText();

        //3. ürüne tıklamak
        WebElement thirdElement = driver.findElement(By.xpath("//div[@data-index = '2']"));
        thirdElement.click();
        Thread.sleep(1000);

        //Ürünü listeye almak. Otomatik olarak wish listesine alıyor, ilk oluşturulan liste olduğundan.
        WebElement addToList = driver.findElement(By.id("add-to-wishlist-button-group"));
        addToList.click();
        Thread.sleep(1500);

        //Çıkan sayfadaki linkten listeye gitmek.
        WebElement wish = driver.findElement(By.xpath("//a[text() = 'Wish']"));
        wish.click();
        Thread.sleep(1000);

        //Listede olup olmadığını check etmek
        Assertions.assertNotNull(driver.findElement(By.linkText(itemName)), "Can't find the required item, somethings wrong");

        //Listeden kaldırmak, her seferinde listeye eklenilen son ürün olduğundan ilk kaldır butonu iş görecektir.
        WebElement delete = driver.findElement(By.xpath("//span[@id = 'a-autoid-7']"));
        delete.click();
        Thread.sleep(1000);

        //Sayfayı yenilemek, değişikliklerin uygulandığından emin olunması için.
        driver.navigate().refresh();
        Thread.sleep(250);

        //Sayfada hala olup olmadığına bakmak.
        Assertions.assertEquals(driver.findElements(By.linkText(itemName)).size(), 0,"Item is not removed, somethings wrong");

        System.out.println("Program is over without bugs.");

    }
}
